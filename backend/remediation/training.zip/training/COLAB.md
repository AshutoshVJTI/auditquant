# Running CodeT5 Fine-Tuning on Google Colab

## Do I need to clone the entire repo?

**No.** You only need:

- The **training scripts** (and, if you’re building data in Colab, the two dataset repos), **or**
- A **pre-made `training_pairs.jsonl`** plus the **training script** `colab_train.py`.

See **Minimal setup** below if you want to avoid cloning the full AuditQuant repo.

---

## Minimal setup (no full repo clone)

### Option 1: Only the training folder

Upload or clone **just** the `backend/remediation/training/` folder (e.g. zip it locally and upload to Colab, or use a sparse checkout). Then in Colab:

```python
# Unzip or cd into the training folder, then:
!pip install -q transformers torch datasets accelerate sentencepiece
!python download_datasets.py
!python prepare_data.py
!python colab_train.py
```

No `PYTHONPATH` or repo root needed; the scripts use paths relative to the script directory. The model is saved to `../models/codet5-solidity-repair` (relative to the training folder); use `--output_dir /content/my_model` to choose another path.

### Option 2: Pre-made JSONL only (fastest)

If you already have `training_pairs.jsonl` (e.g. from running `prepare_data.py` once locally, or from a shared link):

1. Upload **only** `colab_train.py` and `training_pairs.jsonl` to Colab (e.g. to `/content/`).
2. Run:

```python
!pip install -q transformers torch datasets accelerate sentencepiece
!python colab_train.py --data /content/training_pairs.jsonl --output_dir /content/codet5-solidity-repair
```

Then zip and download `/content/codet5-solidity-repair/`. No dataset clone or prepare step.

---

## GPU vs TPU: Which to use?

| | **Colab GPU (T4 / A100)** | **Colab TPU (v2/v3)** |
|---|---|---|
| **Recommendation** | ✅ **Use this** – works with the repo as-is | ⚠️ Possible but more setup |
| **Why** | Hugging Face Trainer + PyTorch are built for GPU. One-click runtime, no extra deps. | Requires `torch_xla`; Colab TPU can have GCS/data constraints; debugging is harder. |
| **Speed** | T4: ~2–4 h, A100: ~1–2 h (typical) | Can be faster for large batches if everything is wired correctly. |
| **Ease** | Runtime → Change runtime type → GPU → run cells | Runtime → TPU → install XLA → run; paths and env differ. |

**Bottom line:** Prefer **Colab GPU** unless you specifically need TPU (e.g. for a course or comparison). The notebook below works on both; GPU is the default and simplest.

---

## Option A: Colab with GPU (recommended)

*If you cloned the full repo (or only the training folder), use these steps.*

1. Open [Google Colab](https://colab.research.google.com).
2. **Runtime → Change runtime type → T4 GPU** (or A100 if available).
3. In the first cell, clone the repo and go to the repo root (or skip and use **Minimal setup** above):

```python
!git clone https://github.com/YOUR_USERNAME/auditquant.git
%cd auditquant
```

4. Run the Colab training script (it will install deps, download data, prepare, train):

```python
!pip install -q transformers torch datasets accelerate sentencepiece
!export PYTHONPATH="${PWD}/backend"
!python backend/remediation/training/download_datasets.py
!python backend/remediation/training/prepare_data.py
!python backend/remediation/training/colab_train.py
```

5. Download the saved model (or sync to Drive):

```python
from google.colab import files
import shutil
# Zip and download
shutil.make_archive("codet5-solidity-repair", "zip", "backend/remediation/models/codet5-solidity-repair")
files.download("codet5-solidity-repair.zip")
```

---

## Option B: Colab with TPU

1. **Runtime → Change runtime type → TPU**.
2. Clone repo and install TPU-enabled PyTorch + deps:

```python
!git clone https://github.com/YOUR_USERNAME/auditquant.git
%cd auditquant
!pip install -q cloud-tpu-client torch-xla
!pip install -q transformers torch datasets accelerate sentencepiece
```

3. Download and prepare data (same as GPU):

```python
import os
os.environ["PYTHONPATH"] = os.getcwd() + "/backend"
!python backend/remediation/training/download_datasets.py
!python backend/remediation/training/prepare_data.py
```

4. Run the Colab-aware training script with TPU:

```python
!python backend/remediation/training/colab_train.py --use_tpu
```

5. If you hit TPU/VM or GCS-related errors, prefer **Option A (GPU)**.

---

## Saving the model for use in AuditQuant

After training, the model is under:

`backend/remediation/models/codet5-solidity-repair/`

- **From Colab:** Zip it and download (see step 5 in Option A), then unzip into `backend/remediation/models/codet5-solidity-repair/` in your local repo.
- **From Colab + Drive:** Copy the folder to Google Drive, then download to the same path locally.

Once that path exists locally, the AuditQuant backend will use the fine-tuned model instead of the placeholder.
