#!/usr/bin/env python3
"""
CodeT5 fine-tuning script for Google Colab (GPU or TPU).

Usage:
  GPU (default):  python colab_train.py
  TPU:           python colab_train.py --use_tpu

When run from Colab, execute from the repo root (e.g. /content/auditquant)
so that paths like backend/remediation/training/data/ resolve correctly.
"""
from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass
class TrainConfig:
    data_path: Path
    checkpoints_dir: Path
    final_model_dir: Path
    model_name: str = "Salesforce/codet5-base"
    max_input_tokens: int = 512
    max_output_tokens: int = 512
    epochs: int = 10
    batch_size: int = 8
    learning_rate: float = 5e-5
    validation_split: float = 0.1
    use_tpu: bool = False


def _colab_friendly_base_dir() -> Path:
    """Resolve training dir so it works when run from repo root (e.g. Colab)."""
    # Same repo-root logic as train.py: parent of this file is 'training/'
    this_file = Path(__file__).resolve()
    return this_file.parent


def _load_jsonl(path: Path) -> list[dict]:
    if not path.exists():
        raise RuntimeError(f"Training data not found at {path}. Run prepare_data.py first.")
    records = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            records.append(json.loads(line))
    if not records:
        raise RuntimeError(f"No training records found in {path}.")
    return records


def main() -> None:
    parser = argparse.ArgumentParser(description="CodeT5 fine-tuning (Colab-friendly, GPU/TPU)")
    parser.add_argument("--use_tpu", action="store_true", help="Use Colab TPU (requires torch_xla)")
    parser.add_argument("--data", type=str, default=None, help="Path to training_pairs.jsonl (default: <script_dir>/data/training_pairs.jsonl)")
    parser.add_argument("--output_dir", type=str, default=None, help="Directory to save final model (default: <script_dir>/../models/codet5-solidity-repair)")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--lr", type=float, default=5e-5)
    args = parser.parse_args()

    base_dir = _colab_friendly_base_dir()
    data_path = Path(args.data) if args.data else base_dir / "data" / "training_pairs.jsonl"
    final_model_dir = Path(args.output_dir) if args.output_dir else base_dir.parent / "models" / "codet5-solidity-repair"
    config = TrainConfig(
        data_path=data_path,
        checkpoints_dir=base_dir / "checkpoints",
        final_model_dir=final_model_dir,
        epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.lr,
        use_tpu=args.use_tpu,
    )

    try:
        import torch
        from datasets import Dataset
        from transformers import (
            AutoModelForSeq2SeqLM,
            AutoTokenizer,
            DataCollatorForSeq2Seq,
            Trainer,
            TrainingArguments,
        )
    except ImportError as exc:
        raise RuntimeError(
            "Install deps: pip install transformers torch datasets accelerate sentencepiece"
        ) from exc

    # Optional: TPU setup (Colab)
    if config.use_tpu:
        try:
            import torch_xla.core.xla_model as xm
            _ = xm.xla_device()
            print("TPU detected. Training on TPU.")
        except Exception as e:
            print(f"TPU requested but not available: {e}. Falling back to CPU/GPU.")
            config.use_tpu = False

    records = _load_jsonl(config.data_path)
    dataset = Dataset.from_list(records)
    split = dataset.train_test_split(test_size=config.validation_split, seed=42)

    tokenizer = AutoTokenizer.from_pretrained(config.model_name)
    model = AutoModelForSeq2SeqLM.from_pretrained(config.model_name)

    def tokenize(batch):
        model_inputs = tokenizer(
            batch["input"],
            max_length=config.max_input_tokens,
            truncation=True,
        )
        labels = tokenizer(
            batch["output"],
            max_length=config.max_output_tokens,
            truncation=True,
        )
        model_inputs["labels"] = labels["input_ids"]
        return model_inputs

    tokenized_train = split["train"].map(tokenize, batched=True, remove_columns=dataset.column_names)
    tokenized_eval = split["test"].map(tokenize, batched=True, remove_columns=dataset.column_names)

    config.checkpoints_dir.mkdir(parents=True, exist_ok=True)
    config.final_model_dir.mkdir(parents=True, exist_ok=True)

    # GPU: fp16; TPU: no fp16 (TPU uses bfloat16 via XLA)
    use_fp16 = torch.cuda.is_available() and not config.use_tpu

    training_args = TrainingArguments(
        output_dir=str(config.checkpoints_dir),
        per_device_train_batch_size=config.batch_size,
        per_device_eval_batch_size=config.batch_size,
        num_train_epochs=config.epochs,
        learning_rate=config.learning_rate,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        save_total_limit=3,
        logging_steps=25,
        remove_unused_columns=True,
        predict_with_generate=True,
        fp16=use_fp16,
        report_to="none",
    )

    # TPU: With --use_tpu we disabled fp16. Trainer auto-detects TPU when torch_xla
    # is installed and Colab TPU runtime is selected (no extra args needed).

    data_collator = DataCollatorForSeq2Seq(tokenizer, model=model)

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_train,
        eval_dataset=tokenized_eval,
        data_collator=data_collator,
        tokenizer=tokenizer,
    )

    trainer.train()
    trainer.save_model(str(config.final_model_dir))
    tokenizer.save_pretrained(str(config.final_model_dir))
    print(f"Model saved to {config.final_model_dir}")


if __name__ == "__main__":
    main()
